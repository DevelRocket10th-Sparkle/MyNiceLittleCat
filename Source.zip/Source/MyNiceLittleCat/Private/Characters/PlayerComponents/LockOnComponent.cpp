// Fill out your copyright notice in the Description page of Project Settings.

#include "Characters/PlayerComponents/LockOnComponent.h"
#include "Camera/PlayerCameraManager.h"
#include "GameFramework/Actor.h"
#include "GameFramework/Character.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/SpringArmComponent.h"
#include "DrawDebugHelpers.h"
#include "Kismet/GameplayStatics.h"
#include "TimerManager.h"

#include "Interfaces/TargetableInterface.h"

// Sets default values for this component's properties
ULockOnComponent::ULockOnComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = false;

	// ...
}

void ULockOnComponent::ToggleTargetLock()
{
    if (LockedTarget.IsValid())
    {
        LockedTarget.Reset();
        return;
    }

    if (CurrentCandidate.IsValid() && Candidates.Contains(CurrentCandidate))
    {
        LockedTarget = CurrentCandidate;
    }

	UpdateReticle();
}

void ULockOnComponent::SwitchTarget(float Direction)
{
    // �� �Է� �� �ĺ��� ��� ����
    RefreshCandidates();

    if (Candidates.Num() < 2) return;

    int32 CurrentIndex = Candidates.IndexOfByKey(CurrentCandidate);

    if (CurrentIndex == INDEX_NONE)
    {
        CurrentIndex = 0;
    }
    AActor* PreviousTarget = CurrentCandidate.Get();

    // ���: ���� �ĺ�, ����: ���� �ĺ�
    const int32 Step = Direction > 0.f ? 1 : -1;

    CurrentIndex = (CurrentIndex + Step + Candidates.Num())
        % Candidates.Num();

    CurrentCandidate = Candidates[CurrentIndex];

    UE_LOG(
        LogTemp,
        Log,
        TEXT("Target Changed: %s -> %s"),
        *GetNameSafe(PreviousTarget),
        *GetNameSafe(CurrentCandidate.Get())
    );

    if (LockedTarget.IsValid())
    {
        LockedTarget = CurrentCandidate;
    }
}


// Called when the game starts
void ULockOnComponent::BeginPlay()
{
	Super::BeginPlay();

    if (ACharacter* PlayerCharacter = Cast<ACharacter>(GetOwner()))
    {
        if (APlayerController* PC =
            Cast<APlayerController>(PlayerCharacter->GetController()))
        {
           // ���� ����

        }
    }

    CameraBoom = GetOwner()? GetOwner()->FindComponentByClass<USpringArmComponent>() : nullptr;

    if (CameraBoom)
    {
        BaseCameraTargetOffset = CameraBoom->TargetOffset;
        BaseCameraArmLength = CameraBoom->TargetArmLength;

        GetWorld()->GetTimerManager().SetTimer(
            CameraFocusTimerHandle,
            this,
            &ULockOnComponent::UpdateLockOnCamera,
            1.0f / 60.0f,
            true
        );
    }

    RefreshCandidates();

    // ��ĵ Ÿ�̸� ����
    if (GetWorld())
    {
        GetWorld()->GetTimerManager().SetTimer(
            ScanTimerHandle,
            this,
            &ULockOnComponent::RefreshCandidates,
            FMath::Max(ScanInterval, 0.03f),
            true
        );
    }
	
}

void ULockOnComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
    if (GetWorld())
    {
        GetWorld()->GetTimerManager().ClearTimer(ScanTimerHandle);
        GetWorld()->GetTimerManager().ClearTimer(CameraFocusTimerHandle);
    }

    Super::EndPlay(EndPlayReason);
}

void ULockOnComponent::RefreshCandidates()
{
    ACharacter* Character = Cast<ACharacter>(GetOwner());

    if (!Character)
    {
        Candidates.Reset();
        CurrentCandidate.Reset();
        LockedTarget.Reset();
		UpdateReticle();
        return;
    }

    APlayerController* PC = Cast<APlayerController>(Character->GetController());

    if (!PC || !PC->IsLocalController()) return;

    TArray<AActor*> FoundActors;
    UGameplayStatics::GetAllActorsWithInterface(
        GetWorld(),
        UTargetableInterface::StaticClass(),
        FoundActors
    );

    TArray<TWeakObjectPtr<AActor>> NewCandidates;

    for (AActor* Actor : FoundActors)
    {
		if (!IsValidCandidate(Actor)) continue;

        FVector2D ScreenPosition;

        if (!GetTargetScreenPosition(Actor, ScreenPosition)) continue;

        NewCandidates.Add(Actor);
    }

    // �÷��̾�� ����� ������ ����
    NewCandidates.Sort(
        [Character](
            const TWeakObjectPtr<AActor>& A,
            const TWeakObjectPtr<AActor>& B)
        {
            if (!A.IsValid()) return false;
            if (!B.IsValid()) return true;

            return FVector::DistSquared(Character->GetActorLocation(), A->GetActorLocation())
                   <
                   FVector::DistSquared(Character->GetActorLocation(), B->GetActorLocation());
        }
    );

    Candidates = MoveTemp(NewCandidates);

    // ���� ����� �� �̻� �ĺ��� �ƴϸ� ���� ����
    if (LockedTarget.IsValid() && !Candidates.Contains(LockedTarget) && !ITargetableInterface::Execute_IsTargetAlive(LockedTarget.Get()))
    {
        LockedTarget.Reset();
    }

    // ���� ������ ������� �� ���� ����� ������� ����
    if (!CurrentCandidate.IsValid() || !Candidates.Contains(CurrentCandidate))
    {
        AActor* PreviousTarget = CurrentCandidate.Get();

        CurrentCandidate.Reset();

        AActor* NewTarget = CurrentCandidate.Get();

        if (PreviousTarget != NewTarget)
        {
            UE_LOG(
                LogTemp,
                Log,
                TEXT("Target Changed: %s -> %s"),
                *GetNameSafe(PreviousTarget),
                *GetNameSafe(NewTarget)
            );
        }

        if (!Candidates.IsEmpty())
        {
            CurrentCandidate = Candidates[0];
        }
    }

    // ���� ����� �ִٸ� ���� ���ð� ����ȭ
    if (LockedTarget.IsValid())
    {
        CurrentCandidate = LockedTarget;
    }

	UpdateReticle();
}

bool ULockOnComponent::GetTargetScreenPosition(AActor* Target, FVector2D& OutScreenPosition) const
{
    if (!IsValid(Target))  return false;

    const ACharacter* Character = Cast<ACharacter>(GetOwner());
    if (!Character) return false;

    APlayerController* PC = Cast<APlayerController>(Character->GetController());
    if (!PC) return false;

    FVector BoundsOrigin;
    FVector BoundsExtent;
    Target->GetActorBounds(false, BoundsOrigin, BoundsExtent);

    if (!PC->ProjectWorldLocationToScreen(BoundsOrigin, OutScreenPosition, true))
    {
        return false;
    }

    int32 ViewportX = 0;
    int32 ViewportY = 0;
	int32 Margin = 50; // ȭ�� �����ڸ������� ����
    PC->GetViewportSize(ViewportX, ViewportY);

    return OutScreenPosition.X >= Margin
        && OutScreenPosition.X <= ViewportX - Margin
        && OutScreenPosition.Y >= Margin
        && OutScreenPosition.Y <= ViewportY - Margin;
}

bool ULockOnComponent::IsValidCandidate(AActor* Target) const
{
    return IsValid(Target)
        && Target != GetOwner()
        && Target->GetClass()->ImplementsInterface(UTargetableInterface::StaticClass())
        && ITargetableInterface::Execute_IsTargetAlive(Target);
}

void ULockOnComponent::UpdateLockOnCamera()
{
    if (!CameraBoom || !GetOwner()) return;

    FVector DesiredOffset = BaseCameraTargetOffset;
    float DesiredArmLength = BaseCameraArmLength;

    AActor* Target = LockedTarget.Get();

    if (IsValidCandidate(Target))
    {
        const FVector PlayerLocation =
            GetOwner()->GetActorLocation();

        FVector TargetLocation;
        FVector BoundsExtent;

        Target->GetActorBounds(
            false,
            TargetLocation,
            BoundsExtent
        );

        // �÷��̾�� Ÿ�ٱ����� �Ÿ� ����
        const FVector ToTarget =
            TargetLocation - PlayerLocation;

        // �� ��� ������ �߰� ������ ī�޶� �߽����� ����
        DesiredOffset += ToTarget * 0.5f;

        // �Ÿ��� �־������� ī�޶� �ڷ� �̵�
        const float HorizontalDistance = FVector(
            ToTarget.X,
            ToTarget.Y,
            0.0f
        ).Size();

        const float ExtraArmLength = FMath::Clamp(
            (HorizontalDistance - ZoomDistanceThreshold)
            * ZoomDistanceScale,
            0.0f,
            MaxExtraArmLength
        );

        DesiredArmLength =
            BaseCameraArmLength + ExtraArmLength;
    }

    // ī�޶� �߽ɰ� ���� �ε巴�� ����
    constexpr float TimerDeltaTime = 1.0f / 60.0f;

    CameraBoom->TargetOffset = FMath::VInterpTo(
        CameraBoom->TargetOffset,
        DesiredOffset,
        TimerDeltaTime,
        CameraFocusInterpSpeed
    );

    CameraBoom->TargetArmLength = FMath::FInterpTo(
        CameraBoom->TargetArmLength,
        DesiredArmLength,
        TimerDeltaTime,
        CameraFocusInterpSpeed
    );
}

void ULockOnComponent::UpdateReticle()
{
    AActor* Target = LockedTarget.IsValid()
        ? LockedTarget.Get()
        : CurrentCandidate.Get();

    if (!IsValid(Target))
    {
        return;
    }

    FVector Origin;
    FVector Extent;
    Target->GetActorBounds(false, Origin, Extent);

    DrawDebugSphere(
        GetWorld(),
        Origin + FVector(0.f, 0.f, Extent.Z + 20.f),
        20.f,        // ������
        12,          // ���׸�Ʈ
        FColor::Red,
        false,       // ���� ǥ�� ����
        0.15f,       // ǥ�� �ð�
        0,           // ���� �켱����
        2.f          // �� �β�
    );
}




